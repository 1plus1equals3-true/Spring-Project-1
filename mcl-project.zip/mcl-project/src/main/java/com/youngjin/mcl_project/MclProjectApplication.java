package com.youngjin.mcl_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MclProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MclProjectApplication.class, args);
	}

}
